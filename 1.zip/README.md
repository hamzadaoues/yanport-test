# Exécution du projet

## Installation des dépendances
npm install

## Exécution
npm start
